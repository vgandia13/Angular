export interface Aplicacion {
    id: number;
    nombre: string;
    descargas: number;
    gratuita: boolean;
}