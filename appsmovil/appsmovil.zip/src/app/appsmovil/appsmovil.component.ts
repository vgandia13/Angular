import { Component } from '@angular/core';

@Component({
  selector: 'app-appsmovil',
  imports: [],
  templateUrl: './appsmovil.component.html',
  styleUrl: './appsmovil.component.css'
})
export class AppsmovilComponent {

}
